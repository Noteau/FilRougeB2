define({ "api": [
  {
    "type": "post",
    "url": "/group/create",
    "title": "Create A Group with a specific Organizational Unit",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "orgunit_name",
            "description": "<p>Name of the new group's Organizational Unit</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the new Group.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "group_scope_name",
            "description": "<p>GroupScopeName of the new Group Scope.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "group_type_name",
            "description": "<p>GroupTypeName of the new Group Type.</p>"
          },
          {
            "group": "Success 200",
            "optional": false,
            "field": "201",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "name": "CreateGroup",
    "group": "Groups",
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "GroupNotFound",
            "description": "<p>The organizational unit was not found.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "GroupAlreadyExist",
            "description": "<p>The group already exist.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units Name not find or invalid\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 409 Conflict\n{\n  \"error\": \"Group already exist\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Groups"
  },
  {
    "type": "delete",
    "url": "/group/:name/delete",
    "title": "Delete A Group by his name",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Group that will be deleted</p>"
          }
        ]
      }
    },
    "name": "DeleteGroup",
    "group": "Groups",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "204",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitNotFound",
            "description": "<p>The organizational unit was not found or invalid.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units Name not find or invalid\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Groups"
  },
  {
    "type": "get",
    "url": "/groups",
    "title": "Request Groups information",
    "name": "GetGroups",
    "group": "Groups",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Group.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "group_scope_name",
            "description": "<p>GroupScopeName of the Group Scope.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "group_type_name",
            "description": "<p>GroupTypeName of the Group Type.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n\t   {\n\t      \"Network Administration\":{\n\t        \"name\":\"Network Administration\",\n\t\t\t\"group_scope_name\":\"Global\",\n\t\t\t\"group_type_name\":\"Security\"\n\t      }\n\t      \"Developper\": {\n\t        \"Name\":\"Developper\",\n\t \t\t\"group_scope_name\":\"Universal\",\n\t\t\t\"group_type_name\":\"Distribution\"\n\t      }\n\t   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "GroupsNotFound",
            "description": "<p>The list of groups was not found.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Groups not found\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Groups"
  },
  {
    "type": "put",
    "url": "/group/:name/modify",
    "title": "Modify A Group",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Previous Name of the Group</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "group_scope_name",
            "description": "<p>New Name of the Group's scope</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "group_type_name",
            "description": "<p>New Name of the Group's type</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "orgunit_name",
            "description": "<p>New Name of the Group's Organizational Unit</p>"
          }
        ]
      }
    },
    "name": "ModifyGroup",
    "group": "Groups",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "204",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitNotFound",
            "description": "<p>The organizational unit was not found or invalid.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units Name not find or invalid\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Groups"
  },
  {
    "type": "post",
    "url": "/orgunits/create",
    "title": "Create A New Organizational Unit",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the new Organizational Unit</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "distinguished_name",
            "description": "<p>DistinguishedName of the new Organizational Unit</p>"
          }
        ]
      }
    },
    "name": "CreateOrgUnit",
    "group": "OrgUnits",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "201",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitNotCreated",
            "description": "<p>The organizational unit was not created.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitAlreadyExist",
            "description": "<p>The organizational unit already exist.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units Name not find or invalid\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 409 Conflict\n{\n  \"error\": \"Organizational Units already exist\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "OrgUnits"
  },
  {
    "type": "delete",
    "url": "/orgunits/:name/delete",
    "title": "Delete A Organizational Unit by his name",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the Organizational Unit that will be deleted</p>"
          }
        ]
      }
    },
    "name": "DeleteOrgUnit",
    "group": "OrgUnits",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "204",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitNotDeleted",
            "description": "<p>The organizational unit was not deleted.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units Name not find or invalid\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "OrgUnits"
  },
  {
    "type": "get",
    "url": "/orgunits",
    "title": "Request organizational Units information",
    "name": "GetOrgUnits",
    "group": "OrgUnits",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the organizational Unit.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "distinguished_name",
            "description": "<p>DistinguishedName of the organizational Unit.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n\t   {\n\t      \"Comptability\":{\n\t        \"name\":\"Comptability\",\n\t \t\t\"distinguished_name\":\"OU=Comptability,DC=Boldeo,DC=COM\"\n\t      }\n\t      \"Administration\": {\n\t        \"name\":\"Administration\",\n\t \t\t\"distinguished_name\":\"OU=Administration,DC=Boldeo,DC=COM\"\n\t      }\n\t   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitsNotFound",
            "description": "<p>The list of organizational units was not found.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"organizational Units not found\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "OrgUnits"
  },
  {
    "type": "put",
    "url": "/orgunits/:name/modify",
    "title": "Modify A Organizational Unit",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Previous Name of the Organizational Unit</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "new_name",
            "description": "<p>New Name of the Organizational Unit</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "new_distinguished_name",
            "description": "<p>New Distinguished Name of the Organizational Unit</p>"
          }
        ]
      }
    },
    "name": "ModifyOrgUnit",
    "group": "OrgUnits",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "204",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitNotFound",
            "description": "<p>The organizational unit was not found or invalid.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units Name not find or invalid\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "OrgUnits"
  },
  {
    "type": "post",
    "url": "/user/create",
    "title": "Create A User with a specific Organizational Unit and Group",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "orgunit_name",
            "description": "<p>Name of the new user's Organizational Unit</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "group_name",
            "description": "<p>Name of the new user's Group</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the new user.</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "is_admin",
            "description": "<p>If the user is an administrator or not.</p>"
          },
          {
            "group": "Success 200",
            "optional": false,
            "field": "201",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "name": "CreateUser",
    "group": "Users",
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "GroupNotFound",
            "description": "<p>The organizational unit or group was not found.</p>"
          },
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "GroupAlreadyExist",
            "description": "<p>The user already exist.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units or Group not find or invalid\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 409 Conflict\n{\n  \"error\": \"User already exist\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Users"
  },
  {
    "type": "delete",
    "url": "/user/:name/delete",
    "title": "Delete A User by his name",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the User that will be deleted</p>"
          }
        ]
      }
    },
    "name": "DeleteUser",
    "group": "Users",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "204",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitNotFound",
            "description": "<p>The Organizational Units, group or user was not found or invalid.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units, group or user not find or invalid\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Users"
  },
  {
    "type": "get",
    "url": "/users",
    "title": "Request Users information",
    "name": "GetUsers",
    "group": "Users",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Name of the User.</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "is_admin",
            "description": "<p>If the user is an administrator or not.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "group_name",
            "description": "<p>Name of the User's Group.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "orgunit_name",
            "description": "<p>Name of the User's organizational Unit.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n\t   {\n\t      \"Billy Crocforde\":{\n\t        \"name\":\"Billy Crocforde\",\n\t\t\t\"is_admin\":\"false\",\n\t\t\t\"group_name\":\"Developper\",\n\t\t\t\"orgunit_name\":\"IT\"\n\t      }\n\t      \"Katrina Poliushka\": {\n\t        \"Name\":\"Katrina Poliushka\",\n\t \t\t\"group_name\":\"Administration\",\n\t\t\t\"orgunit\":\"Administration\"\n\t      }\n\t   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "UsersNotFound",
            "description": "<p>The list of users was not found.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Users not found\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Users"
  },
  {
    "type": "put",
    "url": "/user/:name/modify",
    "title": "Modify A User",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>Previous Name of the User</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "orgunit_name",
            "description": "<p>New Name of the user's Organizational Unit</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "group_name",
            "description": "<p>New Name of the user's Group</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "new_name",
            "description": "<p>New Name of the user.</p>"
          },
          {
            "group": "Success 200",
            "type": "boolean",
            "optional": false,
            "field": "is_admin",
            "description": "<p>If the user is an administrator or not.</p>"
          },
          {
            "group": "Success 200",
            "optional": false,
            "field": "204",
            "description": "<p>success_code</p>"
          }
        ]
      }
    },
    "name": "ModifyUser",
    "group": "Users",
    "error": {
      "fields": {
        "Error 4xx": [
          {
            "group": "Error 4xx",
            "optional": false,
            "field": "OrgUnitNotFound",
            "description": "<p>The organizational unit or Group or User was not found or invalid.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"Organizational Units or Groupor User not find or invalid\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/apiDoc.js",
    "groupTitle": "Users"
  }
] });
