define({
  "name": "Red String Project apiDoc",
  "version": "1.0.0",
  "description": "Group Ludovic Delsol, Lilian Mahevas, Nicolas Yoteau and Sylvain Théodore",
  "title": "apiDoc : Red String Project",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-05-16T15:19:24.405Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
